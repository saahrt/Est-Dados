// Refaça o Exercício 3 de Vetor. Agora crie um algoritmo que leia o nome e a idade de 8 pessoas e guarde esses valores em uma matriz. 
// No final, mostre uma listagem contendo apenas os dados das pessoas menores de idade.

// ESTRUTURA DE DADOS - usando loops

const prompt = require('prompt-sync')();

let pessoas = [];

// Ler os dados
for (let i = 0; i < 8; i++) {
    let nome = prompt(`Insira o NOME da ${i + 1}° pessoa: `);
    let idade = parseInt(prompt(`Insira a IDADE da ${i + 1}° pessoa: `));
    
    // Adiciona um array contendo o nome e a idade da pessoa na matriz
    pessoas.push([nome, idade]);
}

// Exibe a listagem de pessoas menores de idade
console.log("\nPessoas menores de idade:");
for (let i = 0; i < 8; i++) {
    if (pessoas[i][1] < 18) { // Verifica se a idade é menor que 18
        console.log(`Nome: ${pessoas[i][0]}, Idade: ${pessoas[i][1]}`);
    }
}