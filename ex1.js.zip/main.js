/******************************************************************************
Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Faça um algoritmo que leia 5 nomes de pessoas e guarde-os em um vetor. No final, mostre uma listagem com todos os nomes informados, na
// ordem inversa daquela em que eles foram digitados

// npm install prompt-sync

const prompt = require('prompt-sync')();

let nomes = Array.from({ length: 5 }, (_, i) => prompt(`Digite o nome da pessoa ${i + 1}: `));
console.log("\nNomes exibidos em ordem:");
console.log(nomes);

console.log("\nNomes na ordem inversa:");
nomes.reverse();
console.log(nomes);
