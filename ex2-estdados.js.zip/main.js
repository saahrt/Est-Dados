/******************************************************************************
Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Desenvolva um algoritmo que leia 10 números inteiros e guarde-os em um vetor. No final, 
// mostre quais são os números pares que foram digitados e em que posições eles estão armazenados.

// ESTRUTURA DE DADOS - usando loops

const prompt = require('prompt-sync')();
let num = [];

for (let i = 0; i < 10; i++) {
    let num1 = prompt("Insira um número: " + (i + 1) + ":");
    num.push(num1); 
}

// mostrar os num pares e suas posições
let ehPar = false;

for (let i = 0; i < num.length; i++) {
    if (num[i] % 2 === 0) {
        console.log(`Número par: ${num[i]} na posição ${i}`);
        ehPar = true;
    }
}

if (!ehPar) {
    console.log("Não foram digitados números pares.");
}